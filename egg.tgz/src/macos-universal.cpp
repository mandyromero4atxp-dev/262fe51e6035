// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("macos universal"); }
int main(){
  announce();
  return lionss_run_workload("macos-universal");
}
