// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("package pkg\n", stdout);
  return lionss_run_workload("package-pkg");
}
