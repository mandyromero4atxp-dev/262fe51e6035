// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("integration tests"); }
int main(){
  announce();
  return lionss_run_workload("integration-tests");
}
